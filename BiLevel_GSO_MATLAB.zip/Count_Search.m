function [F_max]=Count_Search(bin_input)
global nL inter_dis
%% Int.
landa=0.01;
Amn=1;
M=nL;
nVAR=2;
U=[pi pi]; %Teta fi
L=[0 -pi];
array=bin_input;
%% Search parameters
popsize=25;
Scr= 0.4; 
Rang= 0.6;
a=round(sqrt(nVAR+1));
MaxAngle=pi/(a^2);        
Maxa=MaxAngle/2;                      
MaxL=sqrt(sum((U-L).^2));
%% int. population
UL=(U-L);
for k=1:popsize
    popMAT(k,:)=L+rand.*UL;
end
AngleMAT=ones(popsize,nVAR-1);
AngleMAT(:,:)=(pi/4);
[DirectMAT]=DirecCALC(nVAR,popsize,AngleMAT);

for k=1:popsize
PHMAT=popMAT(k,:);
[F]=object_calc(PHMAT,array,M,Amn,landa);
obj(k,1)=F;
end
[obj infoo]=sort(obj);
popMAT=popMAT(infoo,:);
Fin=[obj(1,1)];
%% GSO
iter=0;
maxiter=10;
while (iter<maxiter)
    iter=iter+1;
    %% Producer
    Producer=popMAT(1,:);
    Xp=Producer;
    coode=0;
    Piter=0;
    phiZ=AngleMAT;
    while (coode~=1 && Piter<a)
    Piter=Piter+1;    
    r1=randn;
    r2=rand(popsize,nVAR-1);
    phiR=phiZ+r2*(MaxAngle/2);
    phiL=phiZ-r2*(MaxAngle/2);
    [DirectZ]=DirecCALC(nVAR,popsize,phiZ);
    [DirectR]=DirecCALC(nVAR,popsize,phiR);
    [DirectL]=DirecCALC(nVAR,popsize,phiL);
    Xz=Xp+(r1*MaxL).*DirectZ(1,:);
    Xr=Xp+(r1*MaxL).*DirectR(1,:);
    Xl=Xp+(r1*MaxL).*DirectL(1,:);
    X=[Xz;Xr;Xl];
    XAngle=[phiZ(1,:);phiR(1,:);phiL(1,:)];
for k=1:size(X,1)
        if (X(k,1)>U(1,1))
            X(k,1)=Xp(1);
        end
    end
    for k=1:size(X,1)
        if (X(k,2)>U(1,2))
            X(k,2)=Xp(2);
        end
    end
    for k=1:size(X,1)
        if (X(k,1)<L(1,1))
            X(k,1)=Xp(1);
        end
    end
    for k=1:size(X,1)
        if (X(k,2)<L(1,2))
            X(k,2)=Xp(2);
        end
    end
    for k=1:size(X,1)
    PHMAT=X(k,:);
    [F]=object_calc(PHMAT,array,M,Amn,landa);
    XCost(k,1)=F;
    end    
    [XCost infoo]=sort(XCost);
   XAngle=XAngle(infoo,:);
    if (XCost(1,1)<obj(1,1))
        coode=1;
        Xp=X(1,:);
        AngleMAT(1,:)=XAngle(1,:);
        popMAT(1,:)=Xp;
        break
    end
    r2=rand(popsize,nVAR-1);
    phiZ=phiZ+r2*Maxa;
    end
    
    if (Piter==a)
        phiZ=AngleMAT;
    end
     for k=1:popsize
    PHMAT=popMAT(k,:);
    [F]=object_calc(PHMAT,array,M,Amn,landa);
    obj(k,1)=F;
    end
    [obj infoo]=sort(obj);
    popMAT = popMAT(infoo,:);
    AngleMAT=AngleMAT(infoo,:);
    [DirectMAT]=DirecCALC(nVAR,popsize,AngleMAT);
    %% Scrounger
    ScrPercent=Scr;
    ScrSize=round(ScrPercent*size(popMAT,1));
    Randpop=randperm(size(popMAT,1));
    pro=find(Randpop==1);
    Randpop(pro)=[];
    
    for k=1:ScrSize
        ScrMAT(k,:)=popMAT(Randpop(k),:);
    end
    for k=1:ScrSize
        r3=rand;
        ScrMAT2(k,:)=ScrMAT(k,:)+r3*(Xp-ScrMAT(k,:));
    end
    for k=1:ScrSize
        if (ScrMAT2(k,1)>U(1,1))
            ScrMAT2(k,1)=U(1,1);
        end
    end
    for k=1:ScrSize
        if (ScrMAT2(k,2)>U(1,2))
            ScrMAT2(k,2)=U(1,2);
        end
    end
    for k=1:ScrSize
        if (ScrMAT2(k,1)<L(1,1))
            ScrMAT2(k,1)=L(1,1);
        end
    end
    for k=1:ScrSize
        if (ScrMAT2(k,2)<L(1,2))
            ScrMAT2(k,2)=L(1,2);
        end
    end
 Scrpop=ScrMAT2;
    %% Ranger
    RangPercent=Rang;
    RangSize=round(RangPercent*popsize)-1;
    RangCounter=0;
    for k=ScrSize+1:length(Randpop)
        RangCounter=RangCounter+1;
        RangMAT(RangCounter,:)=popMAT(Randpop(k),:);
        RangAngle(RangCounter,:)=AngleMAT(Randpop(k),:);
    end
    for k=1:RangSize
        r2=rand;
        RangAngle(k,:)=RangAngle(k,:)+r2*Maxa;
    end
    [RangDirectMAT]=DirecCALC(nVAR,RangSize,RangAngle);
    for k=1:RangSize
        r1=randn;
        li1=a.*r1.*MaxL;
        RangMAT2(k,:)=RangMAT(k,:)+li1.*RangDirectMAT(k,:);
    end
       for k=1:RangSize
        if (RangMAT2(k,1)>U(1,1))
            RangMAT2(k,1)=U(1,1);
        end
    end
    for k=1:RangSize
        if (RangMAT2(k,2)>U(1,2))
            RangMAT2(k,2)=U(1,2);
        end
    end
    for k=1:RangSize
        if (RangMAT2(k,1)<L(1,1))
            RangMAT2(k,1)=L(1,1);
        end
    end
    for k=1:RangSize
        if (RangMAT2(k,2)<L(1,2))
            RangMAT2(k,2)=L(1,2);
        end
    end
    RangMAT=RangMAT2;
    %% Combine
    popMAT=[popMAT(1,:);ScrMAT;RangMAT];
    for k=1:popsize
    PHMAT=popMAT(k,:);
    [F]=object_calc(PHMAT,array,M,Amn,landa);
    obj(k,1)=F;
    end
    [obj infoo]=sort(obj);
    popMAT=popMAT(infoo,:);

    if (obj(1,1)<=min(Fin))
        Fin=[Fin obj(1,1)];
    elseif (obj(1,1)>min(Fin))
        Fin=[Fin min(Fin)];
    end
    subplot(2,1,1)
    plot(-Fin,'blue','Linewidth',2.5)
    title(['Max in this iteration = ',num2str(-min(Fin))]);
    grid on
    %xlabel('Iteration')
    ylabel('F_{max}')
    xlabel('Iteration')
    pause(0.00001)
end
%Optimal_solution=popMAT(1,:)
F_max=-Fin(end);
end












