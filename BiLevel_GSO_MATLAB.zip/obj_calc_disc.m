function [OF]=obj_calc_disc(PHMAT)
global nL storage inter_dis
bin_input=reshape(PHMAT,nL,nL);
[F_max]=Count_Search(bin_input);
OF=F_max;
storage=[storage;OF inter_dis PHMAT];
end