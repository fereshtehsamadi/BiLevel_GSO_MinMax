function [F]=object_calc(PHMAT,array,M,Amn,landa)
d=8e-3;
teta=PHMAT(1);
fi=PHMAT(2);
sigma=0;
for m=1:length(array)
    xm=(m-0.5*(M-1))*d;
    for n=1:length(array)
        yn=(n-0.5*(M-1))*d;
        sigma=sigma+Amn*exp(j.*(2*pi/landa).*(xm.*sin(teta).*cos(fi)+yn.*sin(teta).*sin(fi))).*exp(j.*pi.*(array(m,n)));
    end
end
F=-abs(sigma);
end