clear
clc
global nL storage inter_dis
storage=[];
inter_dis=0;
nVar=121;
nL=sqrt(nVar);
%% Making Population
popsize=15;
sample1=[1 0 1 0 1 0 1 0 1 0 1];
sample0=[0 1 0 1 0 1 0 1 0 1 0];
for pup=1:popsize
    m_cand=randi([0 1],1,nVar);
    con_flag=0;
    while (con_flag~=1)
    index1=sum(m_cand);
    index2=0;
    m_cand2=reshape(m_cand,nL,nL);
    for kk=1:length(m_cand2)
        if (m_cand2(kk,1)==1)
            test_index(kk)=sum(xor(m_cand2(kk,:),sample1));
        end
        if (m_cand2(kk,1)==0)
            test_index(kk)=sum(xor(m_cand2(kk,:),sample0));
        end
    end
    
        if (sum(test_index)==0)
            index2=1;
        end

    index3=0;
    m_cand2=reshape(m_cand,nL,nL);
    for kk=1:length(m_cand2)
        if (m_cand2(1,kk)==1)
            test_index(kk)=sum(xor(m_cand2(:,kk),sample1'));
        end
        if (m_cand2(kk,1)==0)
            test_index(kk)=sum(xor(m_cand2(:,kk),sample0'));
        end
    end
        if (sum(test_index)==0)
            index3=1;
        end
    
    if (index1~=0 || index1~=nVar || index2==1 || index3==1)
        conf_flag=1;
        break
    end
    m_cand=randi([0 1],1,nVar);
    end
    pupMAT(pup,:)=m_cand; 
end

subplot(2,1,2)
    plot([],'r','Linewidth',2.5)
    %title(['Objective = ',[]]);
    grid on
    xlabel('Iteration')
    ylabel('Objective')
    pause(0.0001)


%% Evaluation of initial population
for k=1:popsize
    PHMAT=pupMAT(k,:);
    [OF]=obj_calc_disc(PHMAT);
    obj_dis(k,1)=OF;
end
[obj_dis index]=sort(obj_dis);
pupMAT=pupMAT(index,:);
Fin=[obj_dis(1,1)];
Fin_mem=[pupMAT(1,:)];

%% GSO
%iter=0;
maxiter=50;
while (inter_dis<maxiter)
    inter_dis=inter_dis+1;
%% Producer
    producer=pupMAT(1,:);
    obj_pro=obj_dis(1,1);
    lmax=20;
    r4=ceil((nVar-lmax).*rand);
    
    r5=r4+ceil(lmax.*rand);
    PMAT=producer(1,r4:r5);
    k=1;
    teta=length(PMAT);
    for k=1:teta-1
        testmat=PMAT(k:k+1);
        counter=0;
        stateMAT=[0 0;0 1;1 0;1 1];
        for kk=1:4
            if (stateMAT(kk,1)==testmat(1,1) && stateMAT(kk,2)==testmat(1,2))
            else
                counter=counter+1;
                newPMAT(counter,:)=stateMAT(kk,:);
            end
        end
        
        
        PMATr=PMAT;
        PMATr(k:k+1)=newPMAT(1,:);
        PMATz=PMAT;
        PMATz(k:k+1)=newPMAT(2,:);
        PMATl=PMAT;
        PMATl(k:k+1)=newPMAT(3,:);
        
        rr4=length(producer(1:r4))+length(PMATr);
        Xr=[producer(1:r4) PMATr producer(rr4+1:end)];
        Xz=[producer(1:r4) PMATz producer(rr4+1:end)];
        Xl=[producer(1:r4) PMATl producer(rr4+1:end)];
        
        Xrzl=[Xr;Xz;Xl];
        Xrzl=Xrzl(:,1:nVar);
        
        
        for kk=1:3
            PHMAT=Xrzl(kk,:);
            [OF]=obj_calc_disc(PHMAT);
            obj_Xrzl(kk,1)=OF;
        end
        [obj_Xrzl index]=sort(obj_Xrzl);
        Xrzl=Xrzl(index,:);
        
        if (obj_Xrzl(1,1)<obj_pro)
            producer=Xrzl(1,:);
            break
        end
    end
    %% Scroungers
    ScrPercent=0.4;
    ScrSize=round(ScrPercent*size(pupMAT,1));
    Randpop=randperm(size(pupMAT,1));
    pro=find(Randpop==1);
    Randpop(pro)=[];
    Xp=pupMAT(1,:);
    for k=1:ScrSize
    ScrMAT(k,:)=pupMAT(Randpop(k),:);
    end

    for k=1:ScrSize
    Xsc=ScrMAT(k,:);
    DEl=xor(Xp,Xsc);
    r6=ceil((nVar-lmax).*rand);
    r7=r6+ceil(lmax.*rand);
    
    for kk=r6:r7
        if (DEl(1,kk)==1)
           Xsc(1,kk)=Xp(kk);
        end
    end
    ScrPop(k,:)=Xsc;
    end
    %% Ranger
    RangPercent=0.6;
    RangSize=round(RangPercent*popsize)-1;
    RangCounter=0;
    for k=ScrSize+1:length(Randpop)
        RangCounter=RangCounter+1;
        RangMAT(RangCounter,:)=pupMAT(Randpop(k),:);
    end
    
    for k=1:length(RangMAT)
    r8=ceil((nVar-lmax).*rand);
    r9=r8+ceil(lmax.*rand);
    rang_test=randi([0 1],1,r9-r8);
    RangMAT(k,r8:r9-1)=rang_test;
    end
    %% Combine
    pupMAT=[producer;ScrPop;RangMAT];
    for k=1:popsize
        PHMAT=pupMAT(k,:);
        [OF]=obj_calc_disc(PHMAT);
        obj_dis(k,1)=OF;
    end
    [obj_dis index]=sort(obj_dis);
    pupMAT=pupMAT(index,:);
    
    storage2=storage;
    OF_t=min(storage2(:,1));
    b_m=find(storage2(:,1)==OF_t);
    Fin=[Fin OF_t];
    pupMAT(1,:)=storage2(b_m(1),3:end);
    
%     if (obj_dis(1,1)<=min(Fin))
%         Fin=[Fin obj_dis(1,1)];
%         Fin_mem=[Fin_mem;pupMAT(1,:)];
%     elseif (obj_dis(1,1)>min(Fin))
%         Fin=[Fin min(Fin)];
%         b_m=find(Fin==min(Fin));
%         pupMAT(1,:)=Fin_mem(b_m(1),:);
%     end
    clf
    hold on
    subplot(2,1,2)
    plot(Fin,'r','Linewidth',2.5)
    title(['Objective = ',num2str(min(Fin))]);
    grid on
    xlabel('Iteration')
    ylabel('Objective')
    pause(0.0001)
end
Optimal_solution=reshape(pupMAT(1,:),nL,nL) 











