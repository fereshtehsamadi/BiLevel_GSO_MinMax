function [DirectMAT]=DirecCALC(nVAR,popsize,AngleMAT)
DirectMAT=zeros(popsize,nVAR);
for k=1:popsize
    d1=prod(AngleMAT(k,:)); %%% cos is missing
    DirectMAT(k,1)=d1;
    for kk=2:(nVAR-1)
        pp=prod(cos(AngleMAT(k,kk:end)));
        dij=sin(AngleMAT(k,kk-1)).*pp;
        DirectMAT(k,kk)=dij;
    end
    DirectMAT(k,nVAR)=sin(AngleMAT(k,nVAR-1));
end
end